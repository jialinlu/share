# LeNet for MNIST using Keras and TensorFlow
import tensorflow as tf

from tensorflow.keras.optimizers import SGD
from tensorflow.keras.datasets import mnist
import numpy as np
import os

import model

# Add this for quantization part
from libs.quantz import override

# Enable GPU training
physical_devices = tf.config.experimental.list_physical_devices('GPU')
print("All the available GPUs:\n",physical_devices)
if physical_devices:
    gpu=physical_devices[1]
    tf.config.experimental.set_memory_growth(gpu, True)
    tf.config.experimental.set_visible_devices(gpu, 'GPU')


def main():
    # Download the MNIST dataset
    dataset = mnist.load_data()

    train_data = dataset[0][0]
    train_labels = dataset[0][1]

    test_data = dataset[1][0]
    test_labels = dataset[1][1]

    # Reshape the data to a (70000, 28, 28, 1) tensord
    train_data = train_data.reshape([*train_data.shape,1]) / 255.0

    test_data = test_data.reshape([*test_data.shape,1]) / 255.0

    # Tranform training labels to one-hot encoding
    train_labels = np.eye(10)[train_labels]

    # Tranform test labels to one-hot encoding
    test_labels = np.eye(10)[test_labels]

	
    # Quantization part
    # Make sure the overrides are set before the model is created!
    # QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ
	
	# Examples
    override.extr_q_map={"Conv1" : "nearest,12,11"}
    override.weight_q_map={ "Conv1" : "nearest,32,16", "Dense3" : "nearest,32,16"}

    lenet = model.LeNet()

    lenet.summary()

    optimizer = tf.keras.optimizers.SGD(lr=0.01)

    # Compile the network
    lenet.compile(
        loss = "categorical_crossentropy",
        optimizer = optimizer,
        metrics = ["accuracy"])

    # Callbacks
    callbacks_list=[]

    # Train the model
    lenet.fit(
        train_data,
        train_labels,
        batch_size = 128,
        nb_epoch = 100,
        verbose = 1,
        callbacks=callbacks_list)
	# QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ
	
	
    lenet.save_weights('model.h5')
    fsize = os.path.getsize('model.h5')
    fsize = fsize/float(1024*1024)

    # Evaluate the model
    (loss, accuracy) = lenet.evaluate(
        test_data,
        test_labels,
        batch_size = 128,
        verbose = 1)

    # Print the model's accuracy
    print("Test accuracy: %.4f"%(accuracy))
    print("Model Size: %.4fMB"%(fsize))

if __name__ == "__main__":
    main()
